/**
 * @fileOverview models/global.js
 * @author sunweibin
 * @需要用到的全局数据
 */

export default {
  namespace: 'global',
  state: {

  },
  reducers: {},
  effects: {},
  subscriptions: {},
};
