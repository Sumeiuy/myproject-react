import React from 'react';

import styles from './footer.less';

const Footer = () => (
  <div className={styles.footer}>
    华泰证券 版权所有 © 2017
  </div>
);

export default Footer;
