/*
* @Author: yangquanjian
* @Date:   2017-07-28
*/

const customerOptionMap = {
  // 时间选择
  time: [
    {
      key: '518005',
      name: '按年',
    },
    {
      key: '518004',
      name: '按季度',
    },
    {
      key: '518003',
      name: '按月',
    },
  ],
};

export default customerOptionMap;
