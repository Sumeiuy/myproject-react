/**
 * @file empty/Home.js
 *  空白页面，占位使用
 * @author maoquan(maoquan@htsc.com)
 */

export default function Empty() {
  return null;
}
