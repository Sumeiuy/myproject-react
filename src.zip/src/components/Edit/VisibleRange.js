const VisibleRangeAll = [
  {
    name: '经济业务总部',
    id: 'zong',
  },
  {
    name: '南京分公司',
    id: 'nj',
  },
  {
    name: '北京分公司',
    id: 'bj',
  },
  {
    name: '新疆分公司',
    id: 'xj',
  },
  {
    name: '天津分公司',
    id: 'tj',
  },
  {
    name: '合肥分公司',
    id: 'hf',
  },
  {
    name: '黑龙江分公司',
    id: 'hlj',
  },
  {
    name: '西安分公司',
    id: 'xa',
  },
  {
    name: '内蒙古分公司',
    id: 'nmg',
  },
];

export default { VisibleRangeAll };
