import ECharts from 'echarts';
import Wrapper from './wrapper';

const IECharts = Wrapper(ECharts);

export default IECharts;
